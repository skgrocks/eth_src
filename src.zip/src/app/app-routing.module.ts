import { BlockExplorerComponent } from './components/block-explorer/block-explorer.component';
import { UserLoggedInGuard } from './guards/auth.guard';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginGuard } from './guards/login.guard';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'login', component: LoginComponent, canDeactivate: [LoginGuard] },
  { path: 'home', component: HomeComponent, canActivate:[UserLoggedInGuard] },
  { path: 'block-explorer', component: BlockExplorerComponent, canActivate:[UserLoggedInGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
