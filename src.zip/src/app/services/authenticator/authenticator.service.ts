import { User, Wallet } from './../../models/user.model';
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: 'root'
})
export class AuthenticatorService {
  private url: string = environment.api;
  private loggedInUser: Wallet;
  public loginStatusChanged: BehaviorSubject<Wallet> = new BehaviorSubject<Wallet>(null);

  public get LoggedInUser(): Wallet {
    return this.loggedInUser;
  }

  constructor(private http: HttpClient) {
    this.loginStatusChanged.subscribe(value => this.loggedInUser = value);
  }

  public login(userName: string, password: string): Observable<any> {
    return this.http.post(this.url + 'login', {
      userName,
      password
    });
  }

  public signUp(details: User): Observable<any> {
    return this.http.post(this.url + 'signup', {
      details
    });
  }

  public logout() {
    this.loginStatusChanged.next(null);
  }

  public isUserLoggedIn() {
    return !!this.loggedInUser;
  }
}
