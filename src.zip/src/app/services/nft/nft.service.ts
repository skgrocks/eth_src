import { NetworkName } from './../../enums';
import { MintResponse } from './../../models/mint-response.model';
import { Injectable } from '@angular/core';
import GopNftJSON from 'src/app/contract/GopNFT.json';
import { AbiItem } from 'web3-utils'
import { Subject, tap } from 'rxjs';
import { Wallet } from 'src/app/models/user.model';
import { Token } from 'src/app/models/token.model';
declare let window: any;

@Injectable({
  providedIn: 'root'
})
export class NftService {
  private abi = GopNftJSON.gopNft_abi;
  private contractAddress: string;
  private mintedNetwork: NetworkName;
  private mintOwner: Wallet;
  private receiverWallet: Wallet;
  private includeChainId: boolean = false;
  public onResponseReceived: Subject<MintResponse> = new Subject<MintResponse>();
  public onMintReceiverChanged: Subject<Wallet> = new Subject<Wallet>();

  public set ContractNetwork(network: number) {
    this.includeChainId = false;
    switch (network) {
      case 4:
        this.contractAddress = GopNftJSON.rinkeby_contract_Address;
        this.mintedNetwork = NetworkName.Rinkeby;
        break;
      case 3:
        this.contractAddress = GopNftJSON.ropsten_contract_Address;
        this.mintedNetwork = NetworkName.Ropsten;
        break;
      case 1337:
        this.contractAddress = GopNftJSON.privateNode_contract_Address;
        this.mintedNetwork = NetworkName.Private;
        this.includeChainId = true;
        break;
    }
  }

  public get MintedNetwork(): NetworkName {
    return this.mintedNetwork;
  }

  public set MintOwner(owner: Wallet) {
    this.mintOwner = owner;
  }

  public get MintOwner(): Wallet {
    return this.mintOwner;
  }

  public set NFTReceiver(walletAddress: Wallet) {
    this.receiverWallet = walletAddress;
  }

  public get NFTReceiver(): Wallet {
    return this.receiverWallet;
  }

  constructor() {
  }

  private get contract() {
    return new window.web3.eth.Contract(
      this.abi as AbiItem[],
      this.contractAddress
    );
  }

  private validateMintAction(): string {
    let validationMessages = [];
    if (!this.mintOwner) {
      validationMessages.push('Minting account');
    }
    if (!this.receiverWallet) {
      validationMessages.push('NFT Receiver');
    }
    return validationMessages.join(', ');
  }

  public async mintNFT(metadataUri: string) {
    const responseBuilder = (success: boolean, msg: any, hash: string): MintResponse => {
      return {
        artifactId: metadataUri.slice(metadataUri.length - 1),
        success,
        message: msg,
        hash
      };
    };
    const validationMsgs = this.validateMintAction();
    if (validationMsgs.length > 0) {
      this.onResponseReceived.next(responseBuilder(false, {message: 'Set ' + validationMsgs}, null));
      return;
    }

    try {
      // get the nonce - nonce is needed for security reasons.It keeps track of the number of
      // transactions sent from our address and prevents replay attacks.
      const nonce = await window.web3.eth.getTransactionCount(this.mintOwner.walletAddress, 'latest');
      let tx = {};
      if (!this.includeChainId) {
        tx = {
          from: this.mintOwner.walletAddress,
          to: this.contractAddress,
          nonce: nonce,
          gas: 1000000,
          data: this.contract.methods
                  .createNFT(this.receiverWallet.walletAddress, metadataUri)
                  .encodeABI(),
        };
      }
      else {
        tx = {
          from: this.mintOwner.walletAddress,
          to: this.contractAddress,
          nonce: nonce,
          gas: 1000000,
          data: this.contract.methods
                  .createNFT(this.receiverWallet.walletAddress, metadataUri)
                  .encodeABI(),
          chainId: 1984
        };
      }
      const signPromise = window.web3.eth.accounts.signTransaction(tx, this.mintOwner.pvtKey);
      signPromise.then((signedTx) => {
        window.web3.eth.sendSignedTransaction(signedTx.rawTransaction, (err, hash) => {
          if (!err) {
            console.log("Transaction hash: ", hash,
                        "\nYou may check mempool of the eth node n/w (infura/alchemy etc.) to view the status of our transaction!");
            this.onResponseReceived.next(responseBuilder(true, '', hash));
          } else {
            console.log("Something went wrong while submitting our transaction: ", err);
            this.onResponseReceived.next(responseBuilder(false, err, null));
          }
        });
      }).catch((err) => {
        console.log("Promise failed: ", err);
        this.onResponseReceived.next(responseBuilder(false, err, null));
      });
    } catch (error) {
      console.log(error);
      this.onResponseReceived.next(responseBuilder(false, error, null));
    }
  }

  public async getAllTokens(): Promise<Token[]> {
    return await this.contract.getPastEvents('Transfer', {
        filter: {
            _from: '0x0000000000000000000000000000000000000000'
        },
        fromBlock: 0
    });
    // .then((events) => {
    //     for (let event of events) {
    //         console.log(event);
    //     }
    // });
  }
}
