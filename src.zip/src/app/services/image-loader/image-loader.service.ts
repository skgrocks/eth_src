import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { NFT } from 'src/app/models/nft.model';
import { Wallet } from 'src/app/models/user.model';
import { environment } from 'src/environments/environment';
import { Content } from '../../models/content.model';

@Injectable({
  providedIn: 'root'
})
export class ImageLoaderService {
  private url: string = environment.api;
  public onRefresh: Subject<void> = new Subject<void>();

  constructor(private http: HttpClient) { }

  public getMyCollection(userId: number): Observable<NFT[]> {
    return this.http.get<NFT[]>(this.url + 'nft/collection/' + userId);
  }

  public getContent(url: string): Observable<Content> {
    return this.http.get<Content>(url);
  }

  public getWalletsInNetwork(networkId: number): Observable<Wallet[]> {
    return this.http.get<Wallet[]>(this.url + 'wallets/' + networkId);
  }

  public makeAnEntryAboutMint(nft: NFT) {
    return this.http.post(this.url + 'nft/mint', {
      nft
    });
  }

  // public loadNewImage(image: Content) {
  //   return this.http.post<Content>(this.url.concat('newImage'), {
  //     title: image.title,
  //     description: image.description,
  //     imageUrl: image.imageUrl
  //   });
  // }
}
