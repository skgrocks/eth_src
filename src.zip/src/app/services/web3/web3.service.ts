import { Block } from './../../models/block.model';
import { NetworkName } from './../../enums';
import { last, Subject } from 'rxjs';
import { Injectable } from '@angular/core';
import Web3 from 'web3';

declare const window: any;
var Bzz = require('web3-bzz');
var bzz = new Bzz(Bzz.givenProvider || 'http://swarm-gateways.net');

@Injectable({
  providedIn: 'root'
})
export class Web3Service {
  private web3: Web3;
  public refreshBalance: Subject<void> = new Subject<void>();
  public networkChanged: Subject<number> = new Subject<number>();
  public blockInfo: Subject<Block[]> = new Subject<Block[]>();

  public get Web3Instance(): Web3 {
    return this.web3;
  }

  public get Web3Version(): string {
    return this.web3.version;
  }

  constructor() {
    window.ethereum.request({method: 'eth_requestAccounts'});
    this.web3 = new Web3(window.ethereum);
    window.web3 = this.web3;

    // refer to the web3 documentation
    // https://web3js.readthedocs.io/en/v1.2.11/web3-utils.html
    // refer to the metamask documentation for the events
    // https://docs.metamask.io/guide/ethereum-provider.html#events
    // https://docs.metamask.io/guide/initializing-dapps.html#the-contract-network
    // subscribe metamask's account change
    window.ethereum.on('accountsChanged', (accounts) => {
      console.log('accountsChanges',accounts);
    });

     // subscribe metamask's chain change event
    window.ethereum.on('chainChanged', (chainId) => {
      console.log(chainId);
      this.networkChanged.next(+chainId);
    });
  }

  public async getAccounts() {
    return await this.web3.eth.getAccounts();
  }

  public async getEthBalance(accountAddress: string) {
    const balanceInWei = await this.web3.eth.getBalance(accountAddress);
    const balanceInEther = this.web3.utils.fromWei(balanceInWei, 'ether');
    return balanceInEther;
  }

  public async getSmartContractBalance() {
    // return await this.web3.utils.
  }

  public async getConnectedNetwork() {
    return await this.web3.eth.net.getNetworkType();
  }

  public async getTxStatus(txHash: string, callback: any) {
    await this.web3.eth.getTransactionReceipt(txHash, callback);
  }

  public getTxStatusNoCallback(txHash: string) {
    return this.web3.eth.getTransactionReceipt(txHash);
  }

  public async getTransaction(txHash: string) {
    return await this.web3.eth.getTransaction(txHash);
  }

  public async getInputData(inputData: string) {
    return await this.web3.utils.toAscii(inputData);
  }

  public async toGwei(value: string) {
    return await this.web3.utils.fromWei(value, 'Gwei');
  }

  public toEther(value: string) {
    return this.web3.utils.fromWei(value, 'ether');
  }

  public async getLatestBlockInfo() {
    await this.web3.eth.getBlockNumber(async (error, latestBlockNumber: number) => {
      if (!error) {
        const blocks: Block[] = [];
        // crate block list
        for (var i = 0; i < 20; i++) {
          var block = await this.web3.eth.getBlock(latestBlockNumber - i);
          var number = block.number;
          blocks.push({
            blockNumber: number,
            hash: block.hash,
            time: this.convertTimestamp(block.timestamp),
            gas: block.gasUsed
          });
          this.blockInfo.next(blocks);
        }
      }
    });
  }

  private convertTimestamp(time) {
    let d = new Date(time * 1000); // convert the passed timestamp to milliseconds
    const yyyy = d.getFullYear();
    const mm = ('0' + (d.getMonth() + 1)).slice(-2); //months are zero based. add leading 0;
    const dd = ('0' + d.getDate()).slice(-2);
    const hh = d.getHours();
    let h = hh;
    const min = ('0' + d.getMinutes()).slice(-2);
    let ampm = 'AM';

    if (hh > 12) {
      h = hh - 12;
      ampm = 'PM';
    } else if (hh === 12) {
      h = 12;
      ampm = 'PM';
    } else if (hh === 0) {
      h = 12;
    }
    //i.e. 2014-03-24, 3:00PM
    const time1 = yyyy + '-' + mm + '-' + dd + ', ' + h + ':' + min + ' ' + ampm;
    return time1;
  }

  public async switchNetworkChain(chainId: string) {
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId }],
      });
    } catch (switchError) {
      console.log(switchError);
      // This error code indicates that the chain has not been added to MetaMask.
      // if (switchError.code === 4902) {
      //   try {
      //     await window.ethereum.request({
      //       method: 'wallet_addEthereumChain',
      //       params: [
      //         {
      //           chainId: '0xf00',
      //           chainName: '...',
      //           rpcUrls: ['https://...'] /* ... */,
      //         },
      //       ],
      //     });
      //   } catch (addError) {
      //     // handle "add" error
      //   }
      // }
      // handle other "switch" errors
    }
  }


}

