import { AuthenticatorService } from './../../services/authenticator/authenticator.service';
import { Component, Input, NgZone, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Web3Service } from '../../services/web3/web3.service';
import { Wallet } from 'src/app/models/user.model';
import { NetworkName } from 'src/app/enums';

@Component({
  selector: 'app-meta-mask',
  templateUrl: './meta-mask.component.html',
  styleUrls: ['./meta-mask.component.scss']
})
export class MetaMaskComponent implements OnInit, OnChanges {
  public version = 'web3 version';
  @Input('mint-owner') mintOwner: Wallet;
  public connectedNW;
  public loggedIn = false;

  constructor(private webService: Web3Service, private ngZone: NgZone, private authenticator: AuthenticatorService) { }

  ngOnInit() {
    this.authenticator.loginStatusChanged.subscribe(value => this.loggedIn = !!value);
    this.version = this.webService.Web3Version;
    this.getConnectedNetwork();
    this.webService.refreshBalance.subscribe(() => this.refreshAccountBalance());
    this.webService.networkChanged.subscribe((network) => {
      // since this 'networkChanged' event is raised by an external means (by window.ethereum in this case),
      // the update to 'connectedNW' variable is not reflected in the html direclty. Since it is outside the
      // zone of angular, it needs to be run like this, for the angular to detect changes. Using ChangeDetectorRef
      // will only cause the current component to detect the changes where NgZone will detect the changes all over
      // the angular application. Useful article in this regard -
      // https://stackoverflow.com/questions/50519200/angular-6-view-is-not-updated-after-changing-a-variable-within-subscribe

      this.ngZone.run(() => {
        this.refreshAccountBalance();
        if (!network) {
          this.getConnectedNetwork();
        } else {
          this.connectedNW = NetworkName[network];
        }
      });
    });
  }

  private getConnectedNetwork() {
    this.webService.getConnectedNetwork().then(network => {
      if (network && network.toLocaleLowerCase() === 'private') {
        network = NetworkName[NetworkName.Private];
      }
      this.connectedNW = network;
    })
  }

  async ngOnChanges(changes: SimpleChanges) {
    this.getMetaMaskAccount();
  }

  private async getMetaMaskAccount() {
    const accounts: string[] = await this.webService.getAccounts();
    if (!accounts && accounts.length === 0) {
      return;
    }
    if (this.mintOwner) {
      this.mintOwner.accountBalance = await this.getMetaMaskAccountBalance(this.mintOwner.walletAddress);
    }
  }

  private async refreshAccountBalance() {
    if (this.mintOwner) {
      this.mintOwner.accountBalance = await this.getMetaMaskAccountBalance(this.mintOwner.walletAddress);
    }
  }

  private async getMetaMaskAccountBalance(account: string) {
    return await this.webService.getEthBalance(account);
  }
}
