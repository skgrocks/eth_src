import { AuthenticatorService } from './../../services/authenticator/authenticator.service';
import { LoaderService } from './../../services/loader.service';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { take } from 'rxjs/operators';
import { ImageLoaderService } from 'src/app/services/image-loader/image-loader.service';
import { NFT } from 'src/app/models/nft.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  // public images: Image[];
  public collection: NFT[];
  public mintNew: boolean = false;

  constructor(public dialog: MatDialog, private loader: LoaderService,
              private imageLoaderService: ImageLoaderService, private authenticator: AuthenticatorService) { }

  ngOnInit(): void {
    this.imageLoaderService.onRefresh.subscribe(() => this.refresh());
    this.loadAll();
  }

  // private loadAll() {
  //   this.loader.toggleLoader.next(true);
  //   this.imageLoaderService.getImages().pipe(take(1)).subscribe(result => {
  //     this.images = result;
  //     setTimeout(() => {
  //       this.loader.toggleLoader.next(false);
  //     }, 3000);
  //   });
  // }

  public refresh() {
    this.mintNew = false;
    this.loadAll();
  }

  private loadAll() {
    this.loader.toggleLoader.next(true);
    this.imageLoaderService.getMyCollection(this.authenticator.LoggedInUser.userId).pipe(take(1)).subscribe(result => {
      this.collection = result;
      this.loader.toggleLoader.next(false);
    });
  }

  public toggleSpinner() {
    this.loader.toggleLoader.next(true);
  }

  // public addNewImage() {
  //   const dialogRef = this.dialog.open(NewEntryComponent, {
  //     width: '350px'
  //   });

  //   dialogRef.afterClosed().subscribe(result => {
  //     if (result === 'success') {
  //       this.imageLoaderService.getImage(this.images.length + 1)
  //       .pipe(take(1))
  //       .subscribe(result => {
  //         if (result) {
  //           this.images.push(result);
  //         }
  //       });
  //     }
  //   });
  // }
}
