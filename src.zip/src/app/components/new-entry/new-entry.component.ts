import { ImageLoaderService } from './../../services/image-loader/image-loader.service';
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-new-entry',
  templateUrl: './new-entry.component.html',
  styleUrls: ['./new-entry.component.scss']
})
export class NewEntryComponent implements OnInit {
  public error;
  public title = '';
  public description = '';
  public imageUrl = '';

  constructor(private imageLoaderService: ImageLoaderService, public dialogRef: MatDialogRef<NewEntryComponent>,
              @Inject(MAT_DIALOG_DATA) public data) {
                this.error = '';
               }

  ngOnInit(): void {
  }

  public saveEntry() {
    this.error = '';
    if (!this.title.trim() || !this.description.trim() || !this.imageUrl.trim()) return;
    // this.imageLoaderService.loadNewImage({
    //   title: this.title,
    //   description: this.description,
    //   imageUrl: this.imageUrl
    // }).subscribe({
    //   next: (value) => this.dialogRef.close('success'),
    //   error: (err) => this.error = err,
    //   complete: () => {}
    // });
  }

  public onCloseClick() {
    this.dialogRef.close();
  }
}
