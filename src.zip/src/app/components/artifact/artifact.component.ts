import { AuthenticatorService } from './../../services/authenticator/authenticator.service';
import { Web3Service } from './../../services/web3/web3.service';
import { MintResponse } from './../../models/mint-response.model';
import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { Subject, take } from 'rxjs';
import { Content } from 'src/app/models/content.model';
import { NftService } from 'src/app/services/nft/nft.service';
import { NFT } from 'src/app/models/nft.model';
import { ImageLoaderService } from 'src/app/services/image-loader/image-loader.service';
import { NFTStatus } from 'src/app/enums';

@Component({
  selector: 'app-artifact',
  templateUrl: './artifact.component.html',
  styleUrls: ['./artifact.component.scss']
})
export class ArtifactComponent implements OnInit, OnChanges, OnDestroy {
  private destroy: Subject<void> = new Subject<void>();
  private interval;
  public txHash: string;
  public error;
  public success = false;
  public contentUrl: string;
  public content: Content;
  public disableFields: boolean = false;
  public statusLabel: string = 'Minted On';
  public isLoggedInUserMinter: boolean;
  public isOwner: boolean;
  public canNftBeSold: boolean = true;

  @Input('artifact') artifact: NFT;
  @Input('new-nft') isNew: boolean = false;
  @Output() mintEvent = new EventEmitter<void>();
  @Output() refreshBalance = new EventEmitter<void>();
  @Output() refreshCollection = new EventEmitter<void>();
  @Output() cancel = new EventEmitter<void>();

  constructor(private nftService: NftService, private web3Service: Web3Service,
              private imageLoader: ImageLoaderService, private authenticator: AuthenticatorService) { }

  ngOnInit(): void {
    // if this is not new nft scenario
    if (!this.isNew) {
      this.isOwner = this.authenticator.LoggedInUser.userId === this.artifact.ownedBy;
      this.isLoggedInUserMinter = this.authenticator.LoggedInUser.userId === this.artifact.mintedBy;
      this.statusLabel = !this.isLoggedInUserMinter ? 'Received on' : this.statusLabel;
      this.canNftBeSold = this.authenticator.LoggedInUser.userId === this.artifact.ownedBy;
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.artifact) {
      this.imageLoader.getContent(this.artifact.contentUrl)
                      .pipe(take(1))
                      .subscribe(response => {
        this.content = response;
      });
    }
  }

  public openImage() {
    window.open(this.content.imageUrl,'Image','resizable=no,fullscreen=yes,titlebar=no');
  }

  private verifyTxStatus() {
    const callback = (error, receipt) => {
      if (error || receipt) {
        clearInterval(this.interval);
        this.disableFields = false;
        this.txHash = null;
        if (receipt) {
          this.success = true;
          this.makeEntryInAppDb();
          this.web3Service.refreshBalance.next();
        } else {
          this.error = error;
        }
      }
    };
    this.interval = setInterval(() => {
      console.log('checking tx status..');
      this.web3Service.getTxStatus(this.txHash, callback);
    }, 10000);
  }

  private makeEntryInAppDb() {
    const nftReceiver = this.nftService.NFTReceiver;
    this.imageLoader.makeAnEntryAboutMint({
                      contentUrl: this.contentUrl,
                      mintedBy: this.nftService.MintOwner.userId,
                      mintedNetwork: this.nftService.MintedNetwork,
                      mintedTimestamp: new Date(),
                      status: this.authenticator.LoggedInUser.userId === nftReceiver.userId ? NFTStatus.Minted :
                                                                                                   NFTStatus.Transferred,
                      ownedBy: nftReceiver.userId,
                      externalRecipient: null
                    })
                    .pipe()
                    .subscribe(response => {
                      this.contentUrl = '';
                      this.refreshCollection.emit();
                    });
  }

  public async mintNFT() {
    if (!this.contentUrl || this.contentUrl.trim().length < 10) {
      this.error = {message: 'Enter a valid content url'};
      return;
    }
    this.txHash = '';
    this.error = null;
    this.success = false;
    this.nftService.onResponseReceived
        .pipe(take(1))
        .subscribe((response: MintResponse) => {
          if (!response || !response.success) {
            this.error = response.message;
          } else {
            this.disableFields = true;
            this.txHash = response.hash;
            this.verifyTxStatus();
          }
    });
    this.mintEvent.emit();
    // await this.nftService.mintNFT(this.url + 'collection/' + this.artifact.id);
    await this.nftService.mintNFT(this.contentUrl)
  }

  public sellNFT() {

  }

  public onCancel() {
    this.cancel.emit();
  }

  ngOnDestroy(): void {
    this.destroy.next();
    this.destroy.complete();
  }
}
