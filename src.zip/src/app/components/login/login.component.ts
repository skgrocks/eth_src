import { ImageLoaderService } from 'src/app/services/image-loader/image-loader.service';
import { LoaderService } from './../../services/loader.service';
import { Router } from '@angular/router';
import { AuthenticatorService } from './../../services/authenticator/authenticator.service';
import { Component, OnInit } from '@angular/core';
import { Wallet } from 'src/app/models/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public userName: string = '';
  public password: string = '';
  public walletAddress: string = '';
  public walletName: string = '';
  public pvtKey: string = '';
  public network: number = 3;
  public message: string;
  public mode: Mode = Mode.signin;
  public Mode = Mode;
  public isLaunch = 1;

  private wallets = {};

  constructor(private authenticator: AuthenticatorService,
              private loader: LoaderService, private imageLoaderService: ImageLoaderService,
              private router: Router) { }

  ngOnInit(): void {
    setTimeout(() => {
      $('#launch').fadeOut('slow');
      this.isLaunch = 0;
      $('#main').fadeIn('slow');
    }, 4900);
  }

  public login() {
    this.message = null;
    if (!this.validate()) return;

    this.loader.toggleLoader.next(true);
    this.authenticator.login(this.userName, this.password).subscribe({
      next: (response) => {
        if (response) {
          this.authenticator.loginStatusChanged.next(response);
          this.router.navigateByUrl('/home');
        }
      },
      error: (err) => {
        this.message = err.error.message;
        this.loader.toggleLoader.next(false);
        console.log(err)
      },
      complete: () => this.loader.toggleLoader.next(false)

    });
  }

  private validate(): boolean {
    if (!(this.userName.trim().length > 0 && this.password.trim().length > 0)) {
      return false;
    }
    if (this.mode === Mode.signup) {
      if (this.collateWallets.length === 0) return false;
    }
    return true;
  }

  public signup() {
    this.message = null;
    if (this.mode === Mode.signin) {
      const callback = () => {
        this.mode = Mode.signup;
      };
      this.animate(callback);
    } else {
      if (!this.validate()) return;
      //complete the signup process
      this.loader.toggleLoader.next(true);
      this.authenticator.signUp({
        userName: this.userName,
        password: this.password,
        wallets: this.collateWallets()
      }).subscribe({
      next: (response) => {
        if (response) {
          console.log(response);
          this.mode = Mode.signin;
        }
      },
      error: (err) => {
        this.message = err.error.message;
        this.loader.toggleLoader.next(false);
        console.log(err)
      },
      complete: () => this.loader.toggleLoader.next(false)

    });
    }
  }

  public cancel() {
    const callback = () => {
      this.mode = Mode.signin;
      this.userName = '';
      this.password = '';
      this.walletAddress = '';
      this.pvtKey = '';
      // this.network = NetworkName.Rinkeby;
    };
    this.animate(callback);
  }

  private animate(callback) {
    $('#content').fadeOut();
    setTimeout(() => {
      callback();
      $('#content').fadeIn();
    }, 350);
  }

  public onNetworkChanged(networkId) {
    // save the wallet details to the last selected network
    // before loading the details of the currently selected network if the exist
    const wallet = new Wallet();
    wallet.networkId = this.network;
    wallet.walletName = this.walletName;
    wallet.walletAddress = this.walletAddress;
    wallet.pvtKey = this.pvtKey;

    this.wallets[this.network] = wallet;
    this.network = networkId;

    // load the details of the currently selected network
    if (this.wallets[networkId]) {
      this.walletName = this.wallets[networkId].walletName;
      this.walletAddress = this.wallets[networkId].walletAddress;
      this.pvtKey = this.wallets[networkId].pvtKey;
    } else {
      this.walletName = '';
      this.walletAddress = '';
      this.pvtKey = '';
    }
  }

  private collateWallets() {
    const temp: Wallet[] = [];
    if (this.wallets[3] && this.wallets[3].walletName) {
      temp.push(this.wallets[3]);
    }
    if (this.wallets[4] && this.wallets[4].walletName) {
      temp.push(this.wallets[4]);
    }
    if (this.wallets[1984] && this.wallets[1337].walletName) {
      temp.push(this.wallets[1337]);
    }
    return temp;
  }
}

export enum Mode {
  signin = 1,
  signup = 2
}
