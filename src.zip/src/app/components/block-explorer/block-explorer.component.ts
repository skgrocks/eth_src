import { Token } from './../../models/token.model';
import { NftService } from 'src/app/services/nft/nft.service';
import { Observable } from 'rxjs';
import { Component, Inject, OnInit } from '@angular/core';
import { Block } from 'src/app/models/block.model';
import { Web3Service } from 'src/app/services/web3/web3.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Transaction } from 'src/app/models/transaction.model';

@Component({
  selector: 'app-block-explorer',
  templateUrl: './block-explorer.component.html',
  styleUrls: ['./block-explorer.component.scss']
})
export class BlockExplorerComponent implements OnInit {
  public $blocks: Observable<Block[]>;
  public code: Transaction;
  public searchText: string;
  public inputData: string;
  public txStatus: boolean;
  public tokens: Token[];
  public displayedColumns: string[] = ['tokenId', 'address', 'blockNumber', 'event', 'transactionHash',
                                       'from', 'to'];

  constructor(private webService: Web3Service, private nftService: NftService
    // public dialogRef: MatDialogRef<BlockExplorerComponent>,
    // @Inject(MAT_DIALOG_DATA) public data
    ) { }

  ngOnInit(): void {
    this.webService.getLatestBlockInfo();
    this.$blocks = this.webService.blockInfo;
  }

  public async getTxDetails() {
    this.webService.getTxStatusNoCallback(this.searchText).then(result => {
      this.txStatus = result && result.status;
    });
    const x = await this.webService.getTransaction(this.searchText);
    if (x) {
      const y = JSON.stringify(x);
      this.code = JSON.parse(y) as Transaction;

      const prod = +this.code.gasPrice * +this.code.gas;

      this.code.gasFees = await this.webService.toGwei(prod.toString());
      this.code.gasPrice = await this.webService.toEther(this.code.gasPrice);

      const input = await this.webService.getInputData(this.code.input);
      this.inputData = input.split('&')[1];
    }
  }

  public showAllTokens() {
    this.nftService.getAllTokens().then(events => {
      this.tokens = events;
      console.log(events);
    })
  }
}
