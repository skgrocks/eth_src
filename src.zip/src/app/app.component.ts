import { take } from 'rxjs';
import { ImageLoaderService } from 'src/app/services/image-loader/image-loader.service';
import { LoaderService } from './services/loader.service';
import { AuthenticatorService } from './services/authenticator/authenticator.service';
import { Web3Service } from './services/web3/web3.service';
// import { MetaMaskAccount } from './models/meta-mask-account.model';
import { NftService } from 'src/app/services/nft/nft.service';
import { Component, OnInit, NgZone } from '@angular/core';
// import AccountsJSON from './accounts.json';
import { Router } from '@angular/router';
import { Wallet } from './models/user.model';
import { MatDialog } from '@angular/material/dialog';
import { BlockExplorerComponent } from './components/block-explorer/block-explorer.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  private timer;
  public title = 'ng-NFT';

  public block: boolean = false;
  public selectedNetwork = 4;
  public mintOwner;
  public mintOwnerAccName;
  public receiverAccName;
  public customClicked = false;
  public customAddress;
  public loggedIn = false;
  // public accounts: MetaMaskAccount[] = AccountsJSON.accounts as MetaMaskAccount[];
  // public networks = this.accounts.reduce<string[]>((prev, curr) => {
  //   prev.push(...curr.networks);
  //   return prev;
  // }, []);
  public networks = [
    {
      key: 3,
      value: 'Ropsten'
    },
    {
      key: 4,
      value: 'Rinkeby'
    },
    {
      key: 1337,
      value: 'Private Node'
    }
  ];
  public wallets: Wallet[] = [];

  constructor(private ngZone: NgZone, private loader: LoaderService, private imageLoader: ImageLoaderService,
              private nftService: NftService, private web3Service: Web3Service, public dialog: MatDialog,
              private router: Router, private authenticator: AuthenticatorService) {}

  async ngOnInit() {
    this.authenticator.loginStatusChanged.subscribe(async value => {
      this.loggedIn = !!value;
      if (this.loggedIn) {
        await this.initializeSettings();
      }
    });
    this.web3Service.networkChanged.subscribe((network) => {
      this.onNetworkChangedInMetaMask(network);
    });
    this.nftService.onResponseReceived.subscribe(response => {
      this.block = false;
    });
    this.loader.toggleLoader.subscribe(value => {
      this.ngZone.run(() => {
        this.block = value;
      });
    })
  }

  private async initializeSettings() {
    // this.mintOwner = this.metaMaskAccounts[0];
    // this.mintOwnerAccName = this.metaMaskAccounts[0].walletName;
    // this.receiverAccName = this.metaMaskAccounts[1].walletName;
    await this.onNetworkChangedInApp();
    this.onMintOwnerChanged();
    this.onMintReceiverChanged();
  }

  public toggleSettings(show: boolean, event?) {
    if (show) {
      clearTimeout(this.timer);
      $("#settings-div").css({position: "fixed", top: 35, right: 50});
      $('#settings-div').fadeIn();
    } else {
      this.debounce();
    }
  }

  public refreshContent() {
    this.imageLoader.onRefresh.next();
  }

  private debounce() {
    this.timer = setTimeout(() => {
      $('#settings-div').fadeOut('fast');
    }, 600);
  }

  private onNetworkChangedInMetaMask(network: number) {
    this.selectedNetwork = network;
    this.reloadNetworkDependencies();
  }

  public async onNetworkChangedInApp() {
    switch (this.selectedNetwork) {
      case 3:
        await this.web3Service.switchNetworkChain('0x3');
        break;
      case 4:
        await this.web3Service.switchNetworkChain('0x4');
        break;
      case 1337:
        await this.web3Service.switchNetworkChain('0x539');
        break;
    }
    this.reloadNetworkDependencies();
  }

  private reloadNetworkDependencies() {
    this.nftService.NFTReceiver = null;
    this.getWallets();
    this.nftService.ContractNetwork = this.selectedNetwork;
  }

  private getWallets() {
    this.imageLoader.getWalletsInNetwork(this.selectedNetwork)
    .pipe(take(1))
    .subscribe(response => {
      this.wallets = response;
      if (this.wallets) {
        const defaultAcc = this.wallets.find(x => x.userId === this.authenticator.LoggedInUser.userId);
        if (defaultAcc) {
          this.mintOwnerAccName = defaultAcc.walletName;
          this.onMintOwnerChanged();
        }
      }
    });
  }

  public onMintOwnerChanged() {
    if (this.wallets) {
      // this.mintOwner = this.wallets.find(x => x.walletName === this.mintOwnerAccName);
      this.mintOwner = this.wallets.find(x => x.userId === this.authenticator.LoggedInUser.userId);
      if (this.mintOwner) {
        this.nftService.MintOwner =  this.mintOwner;
      }
    }
  }

  public onMintReceiverChanged() {
    if (this.receiverAccName && this.receiverAccName !== 'custom') {
      const receiverWallet = this.wallets.find(x => x.walletName === this.receiverAccName);
      this.nftService.NFTReceiver = receiverWallet;
    }
  }

  public onCustomAddressChanged() {
    this.nftService.NFTReceiver = this.customAddress;
  }

  public logout() {
    this.block = true;
    this.authenticator.logout();
    setTimeout(() => {
      this.block = false;
      this.router.navigateByUrl('/login');
    }, 1000);
  }

  public openBlockExplorer() {
    // const dialogRef = this.dialog.open(BlockExplorerComponent, {
    //   width: '100%'
    // });
    this.router.navigateByUrl('/block-explorer');
    // dialogRef.afterClosed().subscribe(result => {
    //   if (result === 'success') {
    //     this.imageLoaderService.getImage(this.images.length + 1)
    //     .pipe(take(1))
    //     .subscribe(result => {
    //       if (result) {
    //         this.images.push(result);
    //       }
    //     });
    //   }
    // });
  }
}
