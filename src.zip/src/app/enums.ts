export enum NetworkName {
  Ropsten = 3,
  Rinkeby = 4,
  Private = 1337
}
export enum NFTStatus {
  Minted = 'minted',
  Transferred = 'transferred'
}
