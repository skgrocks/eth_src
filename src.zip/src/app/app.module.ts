import { LoginGuard } from './guards/login.guard';
import { NewEntryComponent } from './components/new-entry/new-entry.component';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTableModule } from '@angular/material/table';
import {MatRadioModule} from '@angular/material/radio';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { MetaMaskComponent } from './components/meta-mask/meta-mask.component';
import { ArtifactComponent } from './components/artifact/artifact.component';
import { SettingsComponent } from './components/settings/settings.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { CommonModule } from '@angular/common';
import { UserLoggedInGuard } from './guards/auth.guard';
import { BlockExplorerComponent } from './components/block-explorer/block-explorer.component';

@NgModule({
  declarations: [
    AppComponent,
    NewEntryComponent,
    MetaMaskComponent,
    ArtifactComponent,
    SettingsComponent,
    HomeComponent,
    LoginComponent,
    BlockExplorerComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    HttpClientModule,
    FormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatProgressSpinnerModule,
    MatButtonToggleModule,
    MatIconModule,
    MatInputModule,
    MatRadioModule,
    MatTooltipModule,
    MatTableModule,
    AppRoutingModule
  ],
  providers: [UserLoggedInGuard, LoginGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
