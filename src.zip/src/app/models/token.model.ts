export class Token {
  address: string;
  blockHash: string;
  blockNumber: number;
  event: string;
  removed: boolean;
  signature: string;
  transactionHash: string;
  returnValues: MoreDetails;
}

export class MoreDetails {
  from: string;
  to: string;
  tokenId: string;
}
