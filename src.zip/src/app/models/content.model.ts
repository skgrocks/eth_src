export class Content {
  public id?: string;
  public description: string;
  public imageUrl: string;
  public title: string;
}
