export class Transaction {
  blockHash: string;
  blockNumber: number;
  from: string;
  gas: string;
  gasPrice: string;
  gasFees: string;
  hash: string;
  input: string;
  nonce: number;
  r: string;
  s: string;
  to: string;
  transactionIndex: number;
  type: number;
  v: string;
  value: string;
}
