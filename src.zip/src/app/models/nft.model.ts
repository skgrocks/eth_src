import { NetworkName } from './../enums';
import { NFTStatus } from "../enums";

export class NFT {
    id?: number;
    contentUrl: string;
    tokenId?: number;
    contractId?: number;
    mintedBy: number;
    ownedBy: number;
    mintedTimestamp: Date;
    status: NFTStatus;
    externalRecipient: string;
    mintedNetwork: NetworkName;
}
