export class MintResponse {
  artifactId: string;
  success: boolean;
  message: string;
  hash: string;
}
