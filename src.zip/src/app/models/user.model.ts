import { NetworkName } from './../enums';
export class User {
  id?: number;
  userName: string;
  password: string;
  wallets: Wallet[];
}
export class Wallet {
  userId?: number;
  walletName?: string;
  walletAddress: string;
  pvtKey: string;
  networkId: NetworkName;

  // extended properties (these are not in the api/database)
  accountBalance?: string;
  defaultMintingAccount?: boolean;
}


