export class Block {
  blockNumber: number;
  hash: string;
  time: string;
  gas: number;
}
