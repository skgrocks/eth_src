import { Wallet } from './user.model';

export class MetaMaskAccount {
  networks: string[];
  wallets: Wallet[];
}

// export class Wallet {
//   walletName: string;
//   walletAddress: string;
//   accountBalance?: string;
//   pvtKey: string;
//   defaultMintingAccount: boolean;
// }
