export const environment = {
  production: true,
  api: 'http://localhost:3000/api/',
  RINKEBY_API_URL: 'https://rinkeby.infura.io/v3/fe898e074ae8469f95a91cf816370d9f',
  ROPSTEN_API_URL: 'https://ropsten.infura.io/v3/fe898e074ae8469f95a91cf816370d9f',
};
