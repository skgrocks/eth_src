import { Network } from './network';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { NFTStatus } from "../nft-status.enum";
import { User } from "./user";

@Entity()
export class Wallet {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    userId: number;
    
    @ManyToOne(() => User, user => user.id)
    @JoinColumn({ name: 'userId' })
    user: User;
    
    @Column()
    walletAddress: string;
    
    @Column()
    pvtKey: string;
    
    @Column()
    walletName: string;

    @Column()
    networkId: number;

    @ManyToOne(() => Network, nw=> nw.id)
    @JoinColumn({ name: 'networkId' })
    network: Network;
}