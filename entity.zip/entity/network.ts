import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Network {
    @PrimaryGeneratedColumn()
    id: number;
   
    @Column()
    name: string;
}