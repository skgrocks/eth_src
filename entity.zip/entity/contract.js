"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Contract = void 0;
var user_1 = require("./user");
var typeorm_1 = require("typeorm");
var network_1 = require("./network");
var Contract = /** @class */ (function () {
    function Contract() {
    }
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)(),
        __metadata("design:type", Number)
    ], Contract.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.Column)(),
        __metadata("design:type", String)
    ], Contract.prototype, "address", void 0);
    __decorate([
        (0, typeorm_1.Column)(),
        __metadata("design:type", String)
    ], Contract.prototype, "abi", void 0);
    __decorate([
        (0, typeorm_1.Column)(),
        __metadata("design:type", Number)
    ], Contract.prototype, "deployedBy", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return user_1.User; }, function (user) { return user.id; }),
        (0, typeorm_1.JoinColumn)({ name: 'deployedBy' }),
        __metadata("design:type", user_1.User)
    ], Contract.prototype, "user", void 0);
    __decorate([
        (0, typeorm_1.CreateDateColumn)({ type: 'timestamp' }),
        __metadata("design:type", Date)
    ], Contract.prototype, "deployedOn", void 0);
    __decorate([
        (0, typeorm_1.Column)(),
        __metadata("design:type", Number)
    ], Contract.prototype, "networkId", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return network_1.Network; }, function (network) { return network.id; }),
        (0, typeorm_1.JoinColumn)({ name: 'networkId' }),
        __metadata("design:type", network_1.Network)
    ], Contract.prototype, "network", void 0);
    Contract = __decorate([
        (0, typeorm_1.Entity)()
    ], Contract);
    return Contract;
}());
exports.Contract = Contract;
