import { User } from './user';
import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { Network } from './network';

@Entity()
export class Contract {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    address: string;
    
    @Column()
    abi: string;
    
    @Column()
    deployedBy: number;

    @ManyToOne(() => User, user => user.id)
    @JoinColumn({ name: 'deployedBy' })
    user: User;
    
    @CreateDateColumn({ type: 'timestamp'})
    deployedOn: Date;
    
    @Column()
    networkId: number;

    @ManyToOne(() => Network, network => network.id)
    @JoinColumn({ name: 'networkId' })
    network: Network;
}