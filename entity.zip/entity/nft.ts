import { Contract } from './contract';
import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { NFTStatus } from "../nft-status.enum";
import { User } from './user';
import { Network } from './network';

@Entity()
export class NFT {
    @PrimaryGeneratedColumn()
    id: number;
    @Column()
    contentUrl: string;
    @Column({
        nullable: true
    })
    tokenId: number;
    @Column({
        nullable: true
    })
    contractId: number;
    @ManyToOne(() => Contract, contract => contract.id)
    @JoinColumn({ name: 'contractId' })
    contract: Contract;

    @Column()
    mintedBy: number;
    @ManyToOne(() => User, user => user.id)
    @JoinColumn({ name: 'mintedBy' })
    minter: User;

    @Column({
        nullable: true
    })
    ownedBy: number;
    @ManyToOne(() => User, user => user.id)
    @JoinColumn({ name: 'ownedBy' })
    owner: User;

    @CreateDateColumn({ type: 'timestamp'})
    mintedTimestamp: Date;
    @Column({
        type: 'enum',
        enum: NFTStatus,
        default: NFTStatus.Minted
    })
    status: NFTStatus;
    @Column({
        nullable: true
    })
    externalRecipient: string;

    @Column()
    mintedNetwork: number;
    @ManyToOne(() => Network, network => network.id)
    @JoinColumn({ name: 'mintedNetwork' })
    network: Network;
}