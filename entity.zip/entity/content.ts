import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Content {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    url: string;
    
    @Column()
    title: string;
    
    @Column()
    description: number;
}