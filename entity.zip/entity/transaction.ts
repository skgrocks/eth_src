import { NFT } from './nft';
import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { User } from './user';

@Entity()
export class Transaction {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    nftId: number;
    
    @ManyToOne(() => NFT, nft => nft.id)
    @JoinColumn({ name: 'nftId' })
    nft: NFT;
    
    @Column()
    senderId: number;

    @ManyToOne(() => User, user => user.id)
    @JoinColumn({ name: 'senderId' })
    sender: User;
    
    @Column()
    recipientId: number;

    @ManyToOne(() => User, user => user.id)
    @JoinColumn({ name: 'recipientId' })
    receiver: User;
    
    @Column()
    recipientAddress: string;

    @CreateDateColumn({ type: 'timestamp'})
    performedAt: Date;
}