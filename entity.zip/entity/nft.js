"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NFT = void 0;
var contract_1 = require("./contract");
var typeorm_1 = require("typeorm");
var nft_status_enum_1 = require("../nft-status.enum");
var user_1 = require("./user");
var network_1 = require("./network");
var NFT = /** @class */ (function () {
    function NFT() {
    }
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)(),
        __metadata("design:type", Number)
    ], NFT.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.Column)(),
        __metadata("design:type", String)
    ], NFT.prototype, "contentUrl", void 0);
    __decorate([
        (0, typeorm_1.Column)({
            nullable: true
        }),
        __metadata("design:type", Number)
    ], NFT.prototype, "tokenId", void 0);
    __decorate([
        (0, typeorm_1.Column)({
            nullable: true
        }),
        __metadata("design:type", Number)
    ], NFT.prototype, "contractId", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return contract_1.Contract; }, function (contract) { return contract.id; }),
        (0, typeorm_1.JoinColumn)({ name: 'contractId' }),
        __metadata("design:type", contract_1.Contract)
    ], NFT.prototype, "contract", void 0);
    __decorate([
        (0, typeorm_1.Column)(),
        __metadata("design:type", Number)
    ], NFT.prototype, "mintedBy", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return user_1.User; }, function (user) { return user.id; }),
        (0, typeorm_1.JoinColumn)({ name: 'mintedBy' }),
        __metadata("design:type", user_1.User)
    ], NFT.prototype, "minter", void 0);
    __decorate([
        (0, typeorm_1.Column)({
            nullable: true
        }),
        __metadata("design:type", Number)
    ], NFT.prototype, "ownedBy", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return user_1.User; }, function (user) { return user.id; }),
        (0, typeorm_1.JoinColumn)({ name: 'ownedBy' }),
        __metadata("design:type", user_1.User)
    ], NFT.prototype, "owner", void 0);
    __decorate([
        (0, typeorm_1.CreateDateColumn)({ type: 'timestamp' }),
        __metadata("design:type", Date)
    ], NFT.prototype, "mintedTimestamp", void 0);
    __decorate([
        (0, typeorm_1.Column)({
            type: 'enum',
            enum: nft_status_enum_1.NFTStatus,
            default: nft_status_enum_1.NFTStatus.Minted
        }),
        __metadata("design:type", String)
    ], NFT.prototype, "status", void 0);
    __decorate([
        (0, typeorm_1.Column)({
            nullable: true
        }),
        __metadata("design:type", String)
    ], NFT.prototype, "externalRecipient", void 0);
    __decorate([
        (0, typeorm_1.Column)(),
        __metadata("design:type", Number)
    ], NFT.prototype, "mintedNetwork", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return network_1.Network; }, function (network) { return network.id; }),
        (0, typeorm_1.JoinColumn)({ name: 'mintedNetwork' }),
        __metadata("design:type", network_1.Network)
    ], NFT.prototype, "network", void 0);
    NFT = __decorate([
        (0, typeorm_1.Entity)()
    ], NFT);
    return NFT;
}());
exports.NFT = NFT;
