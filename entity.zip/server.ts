import { Transaction } from './entity/transaction';
import { createConnection } from 'typeorm';
import * as cors from 'cors';
import * as express from 'express';
import { Request, Response } from 'express';
import { User } from './entity/user';
import { NFT } from './entity/nft';
import { Wallet } from './entity/wallet';
import { Contract } from './entity/contract';
import { Network } from './entity/network';
import { NFTStatus } from './nft-status.enum';

createConnection().then(db => {
    const userRepository = db.getRepository(User);
    const walletRepository = db.getRepository(Wallet);
    const nftRepository = db.getRepository(NFT);
    const contractRepository = db.getRepository(Contract);
    const networkRepository = db.getRepository(Network);
    const transactionRepository = db.getRepository(Transaction);
    const app = express();
    app.use(express.json());
    app.options('*', cors());
    app.use(cors());

    app.post('/api/login', async(req: Request, res: Response) => {
        console.log(req.body);
        const record = await userRepository.findOne({where: [{userName: req.body['userName']}]});
        if (record) {
            if (record.password === req.body['password']) {
                const wallet = await walletRepository.findOne({where: [{userId: record.id}]});
                res.json(wallet);
            } else {
                res.status(401).send({
                    message: 'Invalid Credentials.'
                });
            }
        } else {
            res.status(401).send({
                message: 'User does not exist.'
            });
        }
    });

    app.post('/api/signup', async(req: Request, res: Response) => {
        const user = new User();
        user.userName = req.body.details['userName'];
        user.password = req.body.details['password'];
        const newUser = await userRepository.create(user);
        const result = await userRepository.save(newUser);

        const wallets = req.body.details['wallets'];
        wallets.forEach(x => {
            x.networkId = Number(x.networkId);
            x.userId = result.id;
        });
        console.log(wallets);
        const newWallets = await walletRepository.create(wallets);
        await walletRepository.save(newWallets);

        res.json({id: result.id});
    });
    
    app.get('/api/nft/collection/:userId', async(req: Request, res: Response) => {
        console.log(req.params['userId']);
        // one way to get nfts with owner included
        // const item = await nftRepository.find({relations: ['owner']});

        const items = await nftRepository.createQueryBuilder("nft")
                                        .innerJoinAndSelect("nft.owner", "u")
                                        .where("mintedBy = :id OR ownedBy = :id", {
                                            id: +req.params['userId']
                                        })
                                        .getMany();
        res.json(items);
    });
    
    app.get('/api/contracts', async (req: Request, res: Response) => {
        const contracts = await contractRepository.find();
        res.json(contracts);
    });

    app.get('/api/networks', async (req: Request, res: Response) => {
        const networks = await networkRepository.find();
        return res.json(networks);
    });

    // return all the users who are in a given network
    app.get('/api/wallets/:networkId', async (req: Request, res: Response) => {
        const wallets = await walletRepository.find({where: [{networkId: +req.params['networkId']}]});
        return res.json(wallets);
    });

    app.get('/api/nft/transactions/:id', async (req: Request, res: Response) => {
        const transactions = await transactionRepository.find({where: [{nftId: +req.params['id']}]});
        return res.json(transactions);
    });

    app.post('/api/nft/mint', async (req: Request, res: Response) => {
        const newNft = await nftRepository.create(req.body.nft);
        console.log(newNft);
        const result = await nftRepository.save(newNft);

        // const tx: Transaction = new Transaction();
        // tx.nftId = result[0].id;
        // tx.senderId = req.body.nft['mintedBy'];
        // tx.recipientId = req.body.nft['ownedBy'];
        // tx.recipientAddress = req.body.nft['externalRecipient'];
        // tx.performedAt = new Date();
        
        // await transactionRepository.save(tx);
        return res.json(result);
    });

    app.post('/api/nft/sell', async (req: Request, res: Response) => {
        const nftToUpdate = await nftRepository.findOne({where: [{id: +req.body.details['id']}]});
        const currentOwner = nftToUpdate.ownedBy;
        nftToUpdate.ownedBy = req.body.details['ownedBy'];
        nftToUpdate.status = NFTStatus.Transferred;
        nftToUpdate.externalRecipient = req.body.details['externalRecipient'];

        const result = await nftRepository.save(nftToUpdate);

        const tx: Transaction = new Transaction();
        tx.nftId = nftToUpdate.id;
        tx.senderId = currentOwner;
        tx.recipientId = nftToUpdate.ownedBy;
        tx.recipientAddress = nftToUpdate.externalRecipient;
        tx.performedAt = new Date();
        
        await transactionRepository.save(tx);
        return res.json(result);
    });

    const port = process.env.PORT || 3000;
    app.listen(port, () => console.log(`NFT is listening on port ${port}...`));
}).catch(error => {
    console.log('Error occured: ' + error);
});