const NFTImage = require('./nftImage');
const cors = require('cors');
const express = require('express');
const app = express();

app.use(express.json());
app.options('*', cors());
app.use(cors());

const collection = new Array();
collection.push(
    {
      id: 1,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Bubbles - pexels',
      imageUrl: 'http://localhost:81/1.jpg',
      title: 'Bike'
    },
    {
      id: 2,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Library - pexels',
      imageUrl: 'http://localhost:81/2.jpg',
      title: 'Trees'
    },
    {
      id: 3,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Reading - pexels',
      imageUrl: 'http://localhost:81/3.jpg',
      title: 'Story'
    },
    {
      id: 4,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Class - Pexels',
      imageUrl: 'http://localhost:81/4.jpg',
      title: 'Class Room'
    },
    {
      id: 5,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Child - pexels',
      imageUrl: 'http://localhost:81/5.jpg',
      title: 'Fall'
    },
    {
      id: 6,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Sea World - pexels',
      imageUrl: 'http://localhost:81/6.jpg',
      title: 'Library'
    },
    {
      id: 7,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/7.jpg',
      title: 'Colors'
    },
    {
      id: 8,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/8.jpg',
      title: 'Toys'
    },
    {
      id: 9,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/9.jpg',
      title: 'Sky'
    },
    {
      id: 10,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/10.jpg',
      title: 'Sky'
    },
    {
      id: 11,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/11.jpg',
      title: 'Sky'
    },
    {
      id: 12,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/12.jpg',
      title: 'Sky'
    },
    {
      id: 13,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/13.jpg',
      title: 'Sky'
    },
    {
      id: 14,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/14.jpg',
      title: 'Sky'
    },
    {
      id: 15,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/15.jpg',
      title: 'Sky'
    },
    {
      id: 16,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/16.jpg',
      title: 'Sky'
    },
    {
      id: 17,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/17.jpg',
      title: 'Sky'
    },
    {
      id: 18,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/18.jpg',
      title: 'Sky'
    },
    {
      id: 19,
      description: 'Some quick example text to build on the card title and make up the bulk of the card\'s content. Colors - pexels',
      imageUrl: 'http://localhost:81/19.jpg',
      title: 'Sky'
    }
  );

app.get('/api/collection', async(req, res) => {
    res.json(collection);
});

app.get('/api/collection/:id', async(req, res) => {
    var reqId = +req.params['id'];
    if (reqId > collection.length) {
        res.send(`Requested resource - ${reqId} doesn't exist`);
    }
    res.json(collection[reqId - 1]);
});

app.post('/api/newImage', async(req, res) => {
  if (collection.find(x => x.imageUrl.toLowerCase() === req.body['imageUrl'].toLowerCase())) {
    res.status(400).send({
      message: 'Image already exists'
    });
  } else {
    var newAssetId = collection.length + 1;
    var newEntry = new NFTImage(newAssetId, req.body['description'], req.body['imageUrl'], req.body['title']);
    collection.push(newEntry);
  
    res.send(collection[collection.length]);
  }
});

// PORT
const port = process.env.port || 8000;
app.listen(port, () => console.log(`NFT JSON generator is listening on port ${port}...`));