"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var transaction_1 = require("./entity/transaction");
var typeorm_1 = require("typeorm");
var cors = require("cors");
var express = require("express");
var user_1 = require("./entity/user");
var nft_1 = require("./entity/nft");
var wallet_1 = require("./entity/wallet");
var contract_1 = require("./entity/contract");
var network_1 = require("./entity/network");
var nft_status_enum_1 = require("./nft-status.enum");
(0, typeorm_1.createConnection)().then(function (db) {
    var userRepository = db.getRepository(user_1.User);
    var walletRepository = db.getRepository(wallet_1.Wallet);
    var nftRepository = db.getRepository(nft_1.NFT);
    var contractRepository = db.getRepository(contract_1.Contract);
    var networkRepository = db.getRepository(network_1.Network);
    var transactionRepository = db.getRepository(transaction_1.Transaction);
    var app = express();
    app.use(express.json());
    app.options('*', cors());
    app.use(cors());
    app.post('/api/login', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var record, wallet;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log(req.body);
                    return [4 /*yield*/, userRepository.findOne({ where: [{ userName: req.body['userName'] }] })];
                case 1:
                    record = _a.sent();
                    if (!record) return [3 /*break*/, 5];
                    if (!(record.password === req.body['password'])) return [3 /*break*/, 3];
                    return [4 /*yield*/, walletRepository.findOne({ where: [{ userId: record.id }] })];
                case 2:
                    wallet = _a.sent();
                    res.json(wallet);
                    return [3 /*break*/, 4];
                case 3:
                    res.status(401).send({
                        message: 'Invalid Credentials.'
                    });
                    _a.label = 4;
                case 4: return [3 /*break*/, 6];
                case 5:
                    res.status(401).send({
                        message: 'User does not exist.'
                    });
                    _a.label = 6;
                case 6: return [2 /*return*/];
            }
        });
    }); });
    app.post('/api/signup', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var user, newUser, result, wallets, newWallets;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    user = new user_1.User();
                    user.userName = req.body.details['userName'];
                    user.password = req.body.details['password'];
                    return [4 /*yield*/, userRepository.create(user)];
                case 1:
                    newUser = _a.sent();
                    return [4 /*yield*/, userRepository.save(newUser)];
                case 2:
                    result = _a.sent();
                    wallets = req.body.details['wallets'];
                    wallets.forEach(function (x) {
                        x.networkId = Number(x.networkId);
                        x.userId = result.id;
                    });
                    console.log(wallets);
                    return [4 /*yield*/, walletRepository.create(wallets)];
                case 3:
                    newWallets = _a.sent();
                    return [4 /*yield*/, walletRepository.save(newWallets)];
                case 4:
                    _a.sent();
                    res.json({ id: result.id });
                    return [2 /*return*/];
            }
        });
    }); });
    app.get('/api/nft/collection/:userId', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var items;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log(req.params['userId']);
                    return [4 /*yield*/, nftRepository.createQueryBuilder("nft")
                            .innerJoinAndSelect("nft.owner", "u")
                            .where("mintedBy = :id OR ownedBy = :id", {
                            id: +req.params['userId']
                        })
                            .getMany()];
                case 1:
                    items = _a.sent();
                    res.json(items);
                    return [2 /*return*/];
            }
        });
    }); });
    app.get('/api/contracts', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var contracts;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, contractRepository.find()];
                case 1:
                    contracts = _a.sent();
                    res.json(contracts);
                    return [2 /*return*/];
            }
        });
    }); });
    app.get('/api/networks', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var networks;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, networkRepository.find()];
                case 1:
                    networks = _a.sent();
                    return [2 /*return*/, res.json(networks)];
            }
        });
    }); });
    // return all the users who are in a given network
    app.get('/api/wallets/:networkId', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var wallets;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, walletRepository.find({ where: [{ networkId: +req.params['networkId'] }] })];
                case 1:
                    wallets = _a.sent();
                    return [2 /*return*/, res.json(wallets)];
            }
        });
    }); });
    app.get('/api/nft/transactions/:id', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var transactions;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, transactionRepository.find({ where: [{ nftId: +req.params['id'] }] })];
                case 1:
                    transactions = _a.sent();
                    return [2 /*return*/, res.json(transactions)];
            }
        });
    }); });
    app.post('/api/nft/mint', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var newNft, result;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, nftRepository.create(req.body.nft)];
                case 1:
                    newNft = _a.sent();
                    console.log(newNft);
                    return [4 /*yield*/, nftRepository.save(newNft)];
                case 2:
                    result = _a.sent();
                    // const tx: Transaction = new Transaction();
                    // tx.nftId = result[0].id;
                    // tx.senderId = req.body.nft['mintedBy'];
                    // tx.recipientId = req.body.nft['ownedBy'];
                    // tx.recipientAddress = req.body.nft['externalRecipient'];
                    // tx.performedAt = new Date();
                    // await transactionRepository.save(tx);
                    return [2 /*return*/, res.json(result)];
            }
        });
    }); });
    app.post('/api/nft/sell', function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
        var nftToUpdate, currentOwner, result, tx;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, nftRepository.findOne({ where: [{ id: +req.body.details['id'] }] })];
                case 1:
                    nftToUpdate = _a.sent();
                    currentOwner = nftToUpdate.ownedBy;
                    nftToUpdate.ownedBy = req.body.details['ownedBy'];
                    nftToUpdate.status = nft_status_enum_1.NFTStatus.Transferred;
                    nftToUpdate.externalRecipient = req.body.details['externalRecipient'];
                    return [4 /*yield*/, nftRepository.save(nftToUpdate)];
                case 2:
                    result = _a.sent();
                    tx = new transaction_1.Transaction();
                    tx.nftId = nftToUpdate.id;
                    tx.senderId = currentOwner;
                    tx.recipientId = nftToUpdate.ownedBy;
                    tx.recipientAddress = nftToUpdate.externalRecipient;
                    tx.performedAt = new Date();
                    return [4 /*yield*/, transactionRepository.save(tx)];
                case 3:
                    _a.sent();
                    return [2 /*return*/, res.json(result)];
            }
        });
    }); });
    var port = process.env.PORT || 3000;
    app.listen(port, function () { return console.log("NFT is listening on port " + port + "..."); });
}).catch(function (error) {
    console.log('Error occured: ' + error);
});
