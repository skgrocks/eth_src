class NFTImage {
    constructor(id, description, imageUrl, title) {
        this.id = id;
        this.description = description;
        this.imageUrl = imageUrl;
        this.title = title;
    }
}
module.exports = NFTImage;