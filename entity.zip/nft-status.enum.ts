export enum NFTStatus {
    Minted = 'minted',
    Transferred = 'Transferred'
}