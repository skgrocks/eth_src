"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NFTStatus = void 0;
var NFTStatus;
(function (NFTStatus) {
    NFTStatus["Minted"] = "minted";
    NFTStatus["Transferred"] = "Transferred";
})(NFTStatus = exports.NFTStatus || (exports.NFTStatus = {}));
